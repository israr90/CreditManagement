import { Component } from '@angular/core';

@Component({
  selector: 'app-no-ip-address',
  templateUrl: './no-ip-address.component.html',
  styleUrls: ['./no-ip-address.component.scss']
})
export class NoIpAddressComponent {

}
